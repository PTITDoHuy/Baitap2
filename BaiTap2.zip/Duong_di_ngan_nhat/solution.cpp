#include <iostream>
using namespace std;
int main()
{
    int d1, d2, d3;
    cin >> d1 >> d2 >> d3;
    int x1 = d1 + d2 + d3;
    int x2 = d1 * 2 + d2 * 2;
    if (x1 <= x2)
        cout << x1;
    else
        cout << x2;
    return 0;
}
