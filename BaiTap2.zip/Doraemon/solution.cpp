#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int n, m;
    cin >> n >> m;
    int min = ceil(n / 2);
    cout << ceil(1.0 * min / m) * m;
    return 0;
}
