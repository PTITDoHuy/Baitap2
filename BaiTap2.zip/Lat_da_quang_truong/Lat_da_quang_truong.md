# Lát đá quảng trường
Quảng trường Nhà hát ở thủ đô Berland có hình chữ nhật với kích thước n × m mét. Nhân dịp kỷ niệm thành phố, một quyết định đã được đưa ra để lát Quảng trường bằng những viên bằng đá granit vuông. Mỗi viên đá hình vuông có kích thước a × a.

Số lượng viên đá ít nhất cần thiết để lát Quảng trường là bao nhiêu? Nó được phép che phủ bề mặt lớn hơn Quảng trường Nhà hát. Nó không được phép phá vỡ các viên đá. Các cạnh của viên đá phải song song với các cạnh của Quảng trường.

Gợi ý : Tính xem cần bao nhiêu viên đã để phủ kín chiều rộng, chiều dài của HCN rồi đem nhân vs nhau sẽ ra số viên đá cần, chú ý trường hợp n và m chia hết cho a hoặc ko chia hết.

### Input 
- 3 số nguyên dương n, m, a.

### Điều kiện
- 1<=n,m,a<=10^9^

### Output
- Viết số lượng viên đá cần thiết để lát kín quảng trường.

### Ví dụ
Input: 6 6 4
Output: 4