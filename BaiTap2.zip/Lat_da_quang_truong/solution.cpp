#include <iostream>
#include <math.h>
using namespace std;
int main()
{
    int n, m, a;
    cin >> m >> n >> a;
    int cd = ceil(1.0 * m / a);
    int cr = ceil(1.0 * n / a);
    cout << cd * cr;
    return 0;
}
